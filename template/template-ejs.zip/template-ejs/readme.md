## How to install

```bash
npm install
```

### How to configure

Create .env file 
You have an example with .env.example of how to fill the .env

### How to start

```bash
npm run server
```
